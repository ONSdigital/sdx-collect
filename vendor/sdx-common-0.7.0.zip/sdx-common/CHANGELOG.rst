Changelog
=============

0.7.0
-----
- Fixed an issue where image file paths could be made invalid by configuration settings.

0.6.0
-----
- Replace PDF transformer with updated one from SDX-transform-cs
- Add function to set pika logging level
- Add codacy badge
