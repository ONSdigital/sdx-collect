..  Titling
    ##++::==~~--''``

.. log_levels:

Setting Log Levels
::::::::::::::::::

Use this module to set the logging level of imported modules, where they implement
standard python logging setups.

.. automodule:: sdx.common.log_levels
.. autofunction:: sdx.common.log_levels.set_level
